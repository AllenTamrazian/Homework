package cs3220.model;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.format.annotation.DateTimeFormat;

public class Event {
	
	private static int idSeed = 1;
	
	private int id;
	String name;
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	Date eventDate;
	String username;
	private List<String> items;
	
	public Event(String name, Date eventDate, String username, List<String> items) {
		id=idSeed++;
		this.name=name;
		this.eventDate=eventDate;
		this.username=username;
		this.items = new ArrayList<String>();
	}
	public String getName() {
		return name;
	}
	public Date getDate() {
		return eventDate;
	}
	public String getUsername() {
		return username;
	}
	public void setName(String name) {
		this.name=name;
	}
	public void setDate(Date eventDate) {
		this.eventDate=eventDate;
	}
	public void setUsername(String username) {
		this.username=username;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id=id;
	}
	
	public void setItems(List<String> items) {
		this.items = items;
	}

	public List<String> getItems() {
		return items;
	}

}
