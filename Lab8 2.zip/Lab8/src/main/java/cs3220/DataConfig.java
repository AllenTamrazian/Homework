package cs3220;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import cs3220.model.Event;

@Configuration
public class DataConfig {

	private List<Event> entries;

	@Bean
	List<Event> entries()
	{
		List<Event> entries = new ArrayList<Event>();
		Date event1Date = new GregorianCalendar(2023, Calendar.FEBRUARY, 14).getTime();
		Date event2Date = new GregorianCalendar(2023, Calendar.DECEMBER, 14).getTime();
		List<String> items1 = new ArrayList<String>();
		String cookies ="Cookies";
		items1.add(cookies);
		
		entries.add(new Event("Room 19 Valentine Party",(event1Date),"Amy Frank", items1));
		entries.add(new Event("Room 19 Kindergarten Graduation",(event2Date),"Amy Frank", items1));
		return entries;
	}
	
	public Event getEvent(int id) {
		for (Event entry : entries)
			if (entry.getId()== id)
			{
				return entry;
			}
		return null;
	}
	
	
	
}
