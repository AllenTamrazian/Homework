package cs3220.controller;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import cs3220.model.Event;

@Controller
public class MainController {
	
	@Autowired
	private List<Event> entries;
	

	@RequestMapping("/")
	public String index(Model model) {
		model.addAttribute("entries", entries);
		return "ListEvents";
	}
	
	@GetMapping("/AddEvent")
	public String addEvent(Model model) {
		Date event1Date = new GregorianCalendar(2023, Calendar.FEBRUARY, 14).getTime();
		List<String> items1 = new ArrayList<String>();
		String cookies ="Cookies";
		items1.add(cookies);
		System.out.print(items1);
		model.addAttribute("entry", new Event("", event1Date, "", items1));
		return "AddEvent";
	}
	
	@PostMapping("/AddEvent")
	public String addEventToList(Event event) {
		entries.add(event);
		return "redirect:/";
	}
	
	@GetMapping("/EditEvent/{id}")
	public String editEvent(@PathVariable int id, Model model) {
		for(Event event : entries)
			if( event.getId() == id){
				model.addAttribute("entry", event);
			}
		return "EditEvent";
	}
	
	@PostMapping("/EditEvent/{id}")
	public String editEventList(@PathVariable int id, Event newEvent) {
		for(Event event : entries)
			if( event.getId() == id){
				event.setName(newEvent.getName());
				event.setDate(newEvent.getDate());
				event.setUsername(newEvent.getUsername());
			}
		return "redirect:/";
	}
	
	
	@RequestMapping("view/{id}")
	public String view(@PathVariable int id, Model model) {
		for(Event event : entries)
			if( event.getId() == id){
				event.getItems().add("Cookies");
				event.getItems().add("Pizza");
				model.addAttribute("entry", event);
			}
		return "view";
	}
	
	@GetMapping("AddItem/{id}")
	public String addItems(@PathVariable int id, Model model) {
		for(Event event : entries)
			if( event.getId() == id){
				model.addAttribute("entry", event);
			}
		return "AddItem";
	}
	
	@PostMapping("AddItem/{id}")
	public String showAddedItems(@PathVariable int id, String item) {
		for(Event event : entries)
			if( event.getId() == id){
				event.getItems().add(item);
			}
		return "redirect:"+id;
	}
	
}
