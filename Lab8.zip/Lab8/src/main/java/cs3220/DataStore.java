package cs3220;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import cs3220.model.Event;

@Component
public class DataStore {

	private List<Event> events;
	
	public DataStore() {
		events = new ArrayList<Event>();
		events.add(new Event(null, null, null, null));
	}
}
